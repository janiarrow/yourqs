# Bootstrap-form-validator
Bootstrap form validator using jQuery

jQery validator for bootstrap forms.
No more searching for form validators.
Use the validator.js file in your project and make sure you are using bootstrap v 4.0 and above.